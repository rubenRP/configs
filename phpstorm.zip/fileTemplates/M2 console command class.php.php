<?php
namespace ${NAMESPACE}\{$EXTENSION_NAME}\Console\Command;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
/**
 * Class ${COMMAND_NAME}Command
 */
class ${COMMAND_NAME}Command extends Command
{
    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        /**
         *  See for more info 
         * http://symfony.com/doc/current/components/console/introduction.html
         * or
         * https://github.com/magento/magento2-samples/tree/master/sample-module-command
         */
        $this->setName('${COMMAND_NAME_NAMESPACED}')
            ->setDescription('${COMMAND_DESCRIPTION}');
        parent::configure();
    }
    /**
     * {@inheritdoc}
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
    }
}