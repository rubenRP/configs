/**
 * Interface ${NAME}
 */